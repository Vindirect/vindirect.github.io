MINKEN'S SKIRMISH MAPS R5
MinkensSkirmishMapsR5.zip
Download Size: 1230kb
Date: 2012-02-14
Author: Hogmark
URL: www.hogmark.com/generals

Six skirmish maps for for Command & Conquer Generals Zero Hour!
Created with WorldBuilder 0.8 � Electronic Arts Inc.

Optimized for Advanced AI Mod for C&C Generals: Zero Hour v0.98
Get the Advanced AI Mod here:
http://www.cnclabs.com/mods/generals/advancedaimod/

Note that all R4 maps work great with the Advanced AI Mod!

If you are looking for maps for Generals (not Zero Hour) download release 3 (R3)!

INSTALLATION NOTES
Unzip to your Maps folder!
(My Documents\Command and Conquer Generals Zero Hour Data\Maps\)

COMMENTS ON THE MAPS

(See individual readme-files for more info)

- Flooded Island (6)
Any Island reworked, now even more action!

- Massive Attack (6)
A brand new 3 vs 3 tournament map!

- No Retreat (4)
Based on No Surrender.

- Red Cross TE (4)
Third Editiion Red Cross

- Return to Temptation Island (4)
Modification of the original map Temptation Island,

- Rocky Rampage (4)
A brand new large 2 vs 2 map!

HISTORY

2012-02-14
Minken's Skirmish Maps R5
- Added a new map pack (R5) for Command & Conquer Generals Zero Hour!
- Optimized for Advanced AI Mod for C&C Generals: Zero Hour v0.98
- Two brand new killer maps!
- Four modified maps!

2009-03-11
Minken's Skirmish Maps R4
- Added updated map pack (R4) for Command & Conquer Generals Zero Hour!
- Includes all R3 maps!
- New maps: Desert Trap, Fall of Meteors, No Surrender, and Swamp Matrix! :) 

2009-03-10
Minken's Skirmish Maps R3
- R3 maps discontinued!
- No map changes in R3 maps!
- Removed "R3" from file names.
- Removed outdated info from readme-files.

2003-09-30
- My first skirmish map for Zero Hour: Hidden Island

2003-06-21
- Added Any Island to the map pack.

2003-05-01
- Added�Abandoned Territories and Fata Morgana to the map pack.

2003-04-20
Minken's Skirmish Maps R3
- My first 8-player map is here! Area Turns Red
- Two other brand new 8-player maps included: Sin City and Lions Foot
- Added two new 4-player maps: Clutha River & Temptation Island
- Added three modified maps: Desert Maze, Urban Savanna, and Urban Desert
- AI skirmish paths have been rearranged, branched, and tweaked on most maps.
- Added waves to some beaches and ponds on different maps using WAKedit.
- Named buildings for the computer to garrison in (all maps).
- Changed time of day (light settings) on some maps.
- Lots of textures have been fixed (replaced, blended, etc) on many maps.
- Fixed a bunch of 3-way blends on some maps (what could possibly be more fun? ;)
- Terrain smoothing on most maps (then again...)
- Removed map names in Worldbuilder to avoid the word "MISSING:" in the in-game map menu.
- Added a short briefing-script to each map showing my name and URL.
- Tested some alternative skirmish AI behaviour scripts (Almost Human by RVMECH, and ThudAI) but decided to skip them.

2003-03-29
Minken's Skirmish Pack R2
- Fixed pathing for skirmish games (center/backdoor) on all maps.
- Added a modified map: Winter Meadows

2003-03-26
Minken's Skirmish Pack
- Original Map Pack: Anthrax Fortress, Gravel Maze, Ireland Meadows, Kuwait Craters, and Red Cross.

FINAL WORDS
Feel free to distribute this map any way you like!
You download and install this map at your own risk.
Map updates can be downloaded at www.hogmark.com/generals
Make sure you have the latest version available! :)


/Hogmark